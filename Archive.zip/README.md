# rs3-plugin-fleet (MIT)

Plugin Fleet pour RoadSimulator3 : runner multi-véhicules et colonnes
de livraison (in_delivery, delivery_state, event_*).

## Installation (editable)
```bash
pip install -e .
