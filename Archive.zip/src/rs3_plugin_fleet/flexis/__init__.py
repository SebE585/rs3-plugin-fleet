from .enricher import FlexisEnricher
PLUGIN = FlexisEnricher  # pour l’autoload RS3