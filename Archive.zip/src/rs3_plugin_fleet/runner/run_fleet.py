# -*- coding: utf-8 -*-
"""
Runner Fleet — lance une simulation multi-profils à partir d'un YAML.

Usage:
  python -m rs3_plugin_fleet.runner.run_fleet --config path/to/coin-coin-delivery.yaml

Fonctions :
- Charge la config YAML (avec support d'un champ 'profiles'/'fleet').
- Normalise `ctx.sim_start` (UTC) tôt pour éviter les timestamps 1970 plus loin.
- Construit le pipeline via un "builder" ou un "adapter" dynamique, selon ce qui est dispo.
- Affiche les stages découverts et quelques infos utiles (Altitude service, etc.).
- Exécute le pipeline et laisse l'Exporter écrire les fichiers.

Noms d’imports :
- Essaie d'abord rs3_plugin_fleet.adapters.core2_adapter_dyn puis rs3_plugin_fleet.pipeline.builder
"""

from __future__ import annotations

import argparse
import sys
from typing import Any, Dict

import pandas as pd
import yaml
from copy import deepcopy


# --------- Utilities ---------------------------------------------------------

def _load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _tz_aware_utc_from_config(cfg: Dict[str, Any]) -> pd.Timestamp:
    start_at = (
        cfg.get("start_at")
        or cfg.get("simulation", {}).get("start_at")
        or cfg.get("fleet", {}).get("start_at")
    )
    if start_at:
        ts = pd.Timestamp(start_at)
        if ts.tz is None:
            ts = ts.tz_localize("Europe/Paris").tz_convert("UTC")
        else:
            ts = ts.tz_convert("UTC")
        return ts
    return pd.Timestamp.now(tz="UTC")


def _print_pipeline(stages) -> None:
    names = [getattr(s, "name", s.__class__.__name__) for s in stages]
    chain = " → ".join(names)
    print(f"[PIPELINE] Stages before final clamp: {chain}")


# --------- Try imports for builder/adapter -----------------------------------

def _get_builder():
    """
    Renvoie un callable (cfg) -> (pipeline, ctx).
    Ordre d'essai et comportements:
      1) rs3_plugin_fleet.adapters.core2_adapter_dyn
         - si `build_pipeline_and_context` existe, on l'utilise
         - sinon, on construit un builder à partir de get_pipeline_cls/get_context_cls/build_default_stages
      2) rs3_plugin_fleet.pipeline.builder
         - si `build_pipeline_and_context` existe, on l'utilise
    """
    # 1) Adapter dynamique (chemin paquet)
    try:
        import rs3_plugin_fleet.adapters.core2_adapter_dyn as adapter
        if hasattr(adapter, "build_pipeline_and_context"):
            return adapter.build_pipeline_and_context  # type: ignore
        # Fallback: construire un builder à partir des getters exposés
        if all(hasattr(adapter, n) for n in ("get_pipeline_cls", "get_context_cls", "build_default_stages")):
            def _from_adapter(cfg):
                PipelineCls = adapter.get_pipeline_cls()
                ContextCls = adapter.get_context_cls()
                stages = adapter.build_default_stages(cfg)
                pipeline = PipelineCls(stages)
                try:
                    ctx = ContextCls(cfg)  # some Context implementations require cfg
                except TypeError:
                    ctx = ContextCls()
                try:
                    setattr(ctx, "config", cfg)
                except Exception:
                    pass
                return pipeline, ctx
            return _from_adapter
    except Exception:
        pass

    # 2) Adapter dynamique (chemin relatif)
    try:
        from ..adapters import core2_adapter_dyn as adapter  # type: ignore
        if hasattr(adapter, "build_pipeline_and_context"):
            return adapter.build_pipeline_and_context  # type: ignore
        if all(hasattr(adapter, n) for n in ("get_pipeline_cls", "get_context_cls", "build_default_stages")):
            def _from_adapter_rel(cfg):
                PipelineCls = adapter.get_pipeline_cls()
                ContextCls = adapter.get_context_cls()
                stages = adapter.build_default_stages(cfg)
                pipeline = PipelineCls(stages)
                try:
                    ctx = ContextCls(cfg)  # some Context implementations require cfg
                except TypeError:
                    ctx = ContextCls()
                try:
                    setattr(ctx, "config", cfg)
                except Exception:
                    pass
                return pipeline, ctx
            return _from_adapter_rel
    except Exception:
        pass

    # 3) Builder classique (chemin paquet)
    try:
        from rs3_plugin_fleet.pipeline.builder import build_pipeline_and_context  # type: ignore
        return build_pipeline_and_context
    except Exception:
        pass

    # 4) Builder classique (chemin relatif)
    try:
        from ..pipeline.builder import build_pipeline_and_context  # type: ignore
        return build_pipeline_and_context
    except Exception:
        pass

    raise ImportError(
        "Impossible d'importer/constituer build_pipeline_and_context depuis adapters/core2_adapter_dyn ou pipeline/builder."
    )


# --------- main --------------------------------------------------------------

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="RS3 Fleet Runner")
    parser.add_argument(
        "-c",
        "--config",
        required=True,
        help="Chemin vers le YAML de configuration (ex: coin-coin-delivery.yaml)",
    )
    args = parser.parse_args(argv)

    cfg = _load_yaml(args.config)
    profile_name = cfg.get("name") or cfg.get("profile") or cfg.get("fleet", {}).get("name")
    profile_info = cfg.get("profile") or cfg.get("fleet", {}).get("profile")
    if profile_name:
        if profile_info:
            print(f"[RUN] {profile_name} ← profil={profile_info}")
        else:
            print(f"[RUN] {profile_name}")

    # ---------- Build helper ----------
    build = _get_builder()

    def _expand_vehicle_run_cfg(cfg_root: Dict[str, Any], vehicle: Dict[str, Any]) -> Dict[str, Any]:
        """Compose a per-vehicle run config expected by the core pipeline.
        Merges the selected profile into a flat dict and injects the vehicle's stops.
        """
        run = {}
        profiles = cfg_root.get("profiles", {}) or {}
        v_profile = vehicle.get("profile")
        prof = profiles.get(v_profile, {}) if v_profile else {}
        # start with profile block
        run.update(deepcopy(prof))
        # carry top-level knobs if present (do not override explicit profile keys)
        for k in ("osrm","speed_sync","road_enrich","geo_spike_filter","legs_retimer","stop_wait_injector","stop_smoother","validators","exporter","altitude"):
            if k in cfg_root and k not in run:
                run[k] = deepcopy(cfg_root[k])
        # inject vehicle info
        run["vehicle_id"] = vehicle.get("id")
        run["stops"] = deepcopy(vehicle.get("stops", []))
        # name/profile for logs
        run["name"] = cfg_root.get("client") or cfg_root.get("name") or run.get("name") or run.get("vehicle_id")
        run["profile"] = v_profile or run.get("profile")
        return run

    vehicles = cfg.get("vehicles") or []

    # If no vehicles defined, assume cfg already describes a single-run config
    runs = []
    if vehicles:
        for v in vehicles:
            runs.append(_expand_vehicle_run_cfg(cfg, v))
    else:
        runs.append(cfg)

    exit_code = 0

    for i, run_cfg in enumerate(runs, start=1):
        name = run_cfg.get("vehicle_id") or run_cfg.get("name") or f"run-{i:02d}"
        prof = run_cfg.get("profile")
        if name and prof:
            print(f"[RUN] {name} ← profil={prof}")
        elif name:
            print(f"[RUN] {name}")

        # Construit pipeline + contexte
        pipeline, ctx = build(run_cfg)

        # Normalise sim_start tôt
        if not hasattr(ctx, "sim_start"):
            ctx.sim_start = _tz_aware_utc_from_config(run_cfg)

        # Petites infos : altitude service (affiché pour info)
        alt = (run_cfg.get("altitude", {}) or run_cfg.get("plugins", {}).get("altitude", {}) or {})
        base_url = alt.get("base_url") or "http://localhost:5004"
        timeout = float(alt.get("timeout", 30.0))
        print(f"[ALT] Using base_url={base_url}, timeout={timeout:.1f}s")

        try:
            stages = getattr(pipeline, "stages", None) or []
            _print_pipeline(stages)
        except Exception:
            pass

        # Exécution — on autorise deux modes : pipeline.run(ctx) ou pipeline(ctx)
        print("[RUN] Executing…")
        if hasattr(pipeline, "run"):
            result = pipeline.run(ctx)
        else:
            result = pipeline(ctx)  # type: ignore
        print("[RUN] Done.")

    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
